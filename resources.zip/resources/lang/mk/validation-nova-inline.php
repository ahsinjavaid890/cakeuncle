<?php

/*
|--------------------------------------------------------------------------
| Nova Language Lines
|--------------------------------------------------------------------------
|
| The following language lines contain the default error messages used by
| the validator class. Some of these rules have multiple versions such
| as the size rules. Feel free to tweak each of these messages here.
|
*/

return [
    'attached'  => 'Ова поле е веќе прикачен.',
    'relatable' => 'Ова поле може да не биде поврзана со овој ресурс.',
];
