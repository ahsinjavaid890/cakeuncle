<?php

/*
|--------------------------------------------------------------------------
| Nova Language Lines
|--------------------------------------------------------------------------
|
| The following language lines contain the default error messages used by
| the validator class. Some of these rules have multiple versions such
| as the size rules. Feel free to tweak each of these messages here.
|
*/

return [
    'attached'  => 'यह क्षेत्र पहले से ही जुड़ा हुआ है । ',
    'relatable' => 'यह फ़ील्ड इस संसाधन से संबद्ध नहीं हो सकती है । ',
];
